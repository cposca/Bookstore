package restClientTest;

import static org.junit.jupiter.api.Assertions.*;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class OrderServiceTest {

	Client client;

	@BeforeEach
	void setUp() throws Exception {
		client = ClientBuilder.newClient();
	}
	
	void tearDown() throws Exception {
		client.close();
	}

	@Test
	void getOrdersByPartNumberJSONResponsive() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/getJson?partNumber=0");
	
		String response = wt.request(MediaType.APPLICATION_JSON)
		        .get(String.class);
		assertNotNull(response);
		assertEquals("{\n}", response);
	}
	
	@Test
	void getOrdersByPartNumberResponsive() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/get?partNumber=0");
	
		String response = wt.request(MediaType.APPLICATION_XML)
		        .get(String.class);
		assertNotNull(response);
		assertEquals("", response);
	}
	
	@Test
	void getOrdersByPartNumberJsonCorrect() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/getJson?partNumber=1");
		
		String response = wt.request(MediaType.APPLICATION_JSON)
		        .get(String.class);
		String expected = "<purchaseOrder>\r\n" + 
				"    <shipTo>\r\n" + 
				"        <street>123 Yonge St</street>\r\n" + 
				"        <province>ON</province>\r\n" + 
				"        <zip>K1E 6T5</zip>\r\n" + 
				"        <country>Canada</country>\r\n" + 
				"        <phone>647-123-4567</phone>\r\n" + 
				"    </shipTo>\r\n" + 
				"    <Items>\r\n" + 
				"        <productName>b001</productName>\r\n" + 
				"        <price>20</price>\r\n" + 
				"        <partNum>1</partNum>\r\n" + 
				"    </Items>\r\n" + 
				"</purchaseOrder>";
		assertEquals(expected, response);
	}
	
	@Test
	void getOrdersByPartNumberCorrect() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/get?partNumber=1");
		
		String response = wt.request(MediaType.APPLICATION_XML)
		        .get(String.class);
		String expected = "<purchaseOrder>\r\n" + 
				"  <shipTo>\r\n" + 
				"    <street>123 Yonge St</street>\r\n" + 
				"    <province>ON</province>\r\n" + 
				"    <zip>K1E 6T5</zip>\r\n" + 
				"    <country>Canada</country>\r\n" + 
				"    <phone>647-123-4567</phone>\r\n" + 
				"  </shipTo>\r\n" + 
				"  <Items>\r\n" + 
				"    <productName>b001</productName>\r\n" + 
				"    <price>20</price>\r\n" + 
				"    <partNum>1</partNum>\r\n" + 
				"  </Items>\r\n" + 
				"</purchaseOrder>";
		assertEquals(expected.trim(), response.trim());
	}
	
	@Test
	void getOrdersByPartNumberNegative() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/get?partNumber=-1");
		
		String response = wt.request(MediaType.APPLICATION_XML)
		        .get(String.class);
		String expected = "";
		assertEquals(expected.trim(), response.trim());
	}
	
	@Test
	void getOrdersByPartNumberJsonNegative() {
		WebTarget wt = client.target("http://localhost:8080/EECS4314_Project/rest/POService/getJson?partNumber=-1");
		
		String response = wt.request(MediaType.APPLICATION_JSON)
		        .get(String.class);
		String expected = "{\n}";
		assertEquals(expected, response);
	}
}
